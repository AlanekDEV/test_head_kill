
Config = {}
Config.Invincible = true --Do you want the peds to be invincible?
Config.Frozen = true --Do you want the peds to be unable to move? It's probably a yes, so leave true in there.
Config.Stoic = true --Do you want the peds to react to what is happening in their surroundings?
Config.Fade = true-- Do you want the peds to fade into/out of existence? It looks better than just *POP* its there.
Config.Distance = 40.0 --The distance you want peds to spawn at



Config.MinusOne = true

Config.PedList = {
	--------------------------------------------------
	---          LEAKED BY BREKUS                  ---
	--------------------------------------------------


	{
		model = "a_f_m_beach_01",
		coords = vector3(-54.4096, -791.5995, 44.2251), 
		heading = 317.8753,
		gender = "female", 
	    isRendered = false,
        ped = nil,
    }
}