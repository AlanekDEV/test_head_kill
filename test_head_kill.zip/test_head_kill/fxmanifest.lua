fx_version 'cerulean'
game 'gta5' 

lua54 'yes'

client_scripts {
	'config.lua',
	'client/main.lua'
}