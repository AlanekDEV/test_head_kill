ESX = nil

Citizen.CreateThread(function()
    while ESX == nil do
        TriggerEvent('esx:getSharedObject', function(obj) ESX = obj end)
        Citizen.Wait(1000)
    end
end)


Citizen.CreateThread(function()
	while true do
		Citizen.Wait(500)
		for k = 1, #Config.PedList, 1 do
			v = Config.PedList[k]
			local playerCoords = GetEntityCoords(PlayerPedId())
			local dist = #(playerCoords - v.coords)

			if dist < Config.Distance and not v.isRendered then
				local ped = nearPed(v.model, v.coords, v.heading, v.gender, v.animDict, v.animName, v.scenario)
				v.ped = ped
				v.isRendered = true
			end
			
			if dist >= Config.Distance and v.isRendered then
				if Config.Fade then
					for i = 255, 0, -51 do
						Citizen.Wait(50)
						SetEntityAlpha(v.ped, i, false)
					end
				end
				DeletePed(v.ped)
				v.ped = nil
				v.isRendered = false
			end
		end
	end
end)

function nearPed(model, coords, heading, gender, animDict, animName, scenario)
	local genderNum = 0

	RequestModel(GetHashKey(model))
	while not HasModelLoaded(GetHashKey(model)) do
		Citizen.Wait(1)
	end
	
	-- Convert plain language genders into what fivem uses for ped types.
	if gender == 'male' then
		genderNum = 4
	elseif gender == 'female' then 
		genderNum = 5
	else
		print("No gender provided! Check your configuration!")
	end	

	--Check if someones coordinate grabber thingy needs to subract 1 from Z or not.
	if Config.MinusOne then 
		local x, y, z = table.unpack(coords)
		ped = CreatePed(genderNum, GetHashKey(model), x, y, z - 1, heading, false, true)
		
	else
		ped = CreatePed(genderNum, GetHashKey(v.model), coords, heading, false, true)
	end
	
	SetEntityAlpha(ped, 0, false)
	
	if Config.Frozen then
		FreezeEntityPosition(ped, true) --Don't let the ped move.
	end
	
	if Config.Invincible then
		SetEntityInvincible(ped, true) --Don't let the ped die.
	end

	if Config.Stoic then
		SetBlockingOfNonTemporaryEvents(ped, true) --Don't let the ped react to his surroundings.
	end
	
	--Add an animation to the ped, if one exists.
	if animDict and animName then
		RequestAnimDict(animDict)
		while not HasAnimDictLoaded(animDict) do
			Citizen.Wait(1)
		end
		TaskPlayAnim(ped, animDict, animName, 8.0, 0, -1, 1, 0, 0, 0)
	end

	if scenario then
		TaskStartScenarioInPlace(ped, scenario, 0, true) -- begins peds animation
	end
	
	if Config.Fade then
		for i = 0, 255, 51 do
			Citizen.Wait(50)
			SetEntityAlpha(ped, i, false)
		end
	end

	return ped
end


Citizen.CreateThread(function()
	while true do 
		Citizen.Wait(2000)
	local pedzik =	CreatePed(genderNum, GetHashKey('a_f_m_beach_01'), vector3(-50.8293, -795.0550, 44.2251-1.0), 333.6087, false, true)
	FreezeEntityPosition(pedzik, true)
	SetBlockingOfNonTemporaryEvents(pedzik, true)
	SetEntityInvincible(pedzik, false)
		Citizen.Wait(2000)
		DeletePed(pedzik)
	end
end)



local markerCoords = vector3(-50.8293, -795.0550, 44.2251-0.90) -- this can be taken from the config for example
local markerCoords2 = vector3(-54.4096, -791.5995, 44.2251-0.90)
local playerCoords = GetEntityCoords(PlayerId()) -- not sure if that's the correct syntax though
local distance = GetDistanceBetweenCoords(table.unpack(markerCoords), table.unpack(playerCoords), true) -- comparing the values
Citizen.CreateThread(function()
	while true do 
		Citizen.Wait(0)

	    DrawMarker(1, markerCoords.x, markerCoords.y, markerCoords.z, 0, 0, 0, 0, 0, 0, 4.0, 4.0, 1.0, 100, 235, 52, 50, false, false, 0, false)
		DrawMarker(1, markerCoords2.x, markerCoords2.y, markerCoords2.z, 0, 0, 0, 0, 0, 0, 4.0, 4.0, 1.0, 100, 235, 52, 50, false, false, 0, false)
		Draw3DText(markerCoords.x, markerCoords.y, markerCoords.z+1.8, 0.5, "Tutaj sprawdzisz efekt zabójstwa!")
		Draw3DText2(markerCoords.x, markerCoords.y, markerCoords.z+2.2, 1.5, "~h~KILL EFFECT")		
		Draw3DText(markerCoords2.x, markerCoords2.y, markerCoords2.z+1.8, 0.5, "Tutaj sprawdzisz efekt strzału w głowę!")
		Draw3DText2(markerCoords2.x, markerCoords2.y, markerCoords2.z+2.2, 1.5, "~h~HEAD EFFECT")		
	end
end)

function Draw3DText(x, y, z, scl_factor, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local p = GetGameplayCamCoords()
    local distance = GetDistanceBetweenCoords(p.x, p.y, p.z, x, y, z, 1)
    local scale = (1 / distance) * 2
    local fov = (1 / GetGameplayCamFov()) * 100
    local scale = scale * fov * scl_factor
    if onScreen then
        SetTextScale(0.0, scale)
        SetTextFont(0)
        SetTextProportional(1)
        SetTextColour(255, 255, 255, 255)
        SetTextDropshadow(0, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end

function Draw3DText2(x, y, z, scl_factor, text)
    local onScreen, _x, _y = World3dToScreen2d(x, y, z)
    local p = GetGameplayCamCoords()
    local distance = GetDistanceBetweenCoords(p.x, p.y, p.z, x, y, z, 1)
    local scale = (1 / distance) * 2
    local fov = (1 / GetGameplayCamFov()) * 100
    local scale = scale * fov * scl_factor
    if onScreen then
        SetTextScale(0.0, scale)
        SetTextFont(0)
        SetTextProportional(1)
        SetTextColour(163, 93, 7, 255)
        SetTextDropshadow(0, 0, 0, 0, 255)
        SetTextEdge(2, 0, 0, 0, 150)
        SetTextDropShadow()
        SetTextOutline()
        SetTextEntry("STRING")
        SetTextCentre(1)
        AddTextComponentString(text)
        DrawText(_x, _y)
    end
end
		


